#   Cartridge Installer
#       A simple install script to put this
#       cart into slot A
#
#   REQUIRES AMPY

ampy_cmd="ampy --port $1"

$ampy_cmd reset
echo "Reset board."

$ampy_cmd rmdir /slots/a
echo "Removed slot."

$ampy_cmd mkdir /slots/a
echo "Added slot."

$ampy_cmd put cartridge.json /slots/a/cartridge.json
echo "Added config."

$ampy_cmd put scenes /slots/a/scenes
echo "Added scenes."

$ampy_cmd ls /slots/a
$ampy_cmd ls /slots/a/scenes
echo "[DONE]"