# Scene Garbage Collection Test
This Cartridge tests to see if the Garbage Collector is working correctly, and is not incorrectly marking scene-related objects are unused.

After the registration phase of Cartridge bootup, the Scene Manager will add all globals in a file to the registered scene's locals, which causes the Garbage Collector to see those objects as valid & used objects even after the execution of the file.

If this Cartridge can be left on for a minute or so, then the Garbage Collector is working fine and is not incorrectly marking objects as invalid.