import lpp_scene_manager as scene_manager
import lpp_time as lptime
import lpp_draw as draw
import lpp_color as color
import lpp_lightstrip as lightstrip
import gc


# Register this as a Scene file
scene_manager.register_scene("Test A")

def setup(scene):
    scene.stay_time = 1     # How long the scene should linger for

def start(scene):
    print("\nHello from Test A!")
    extra_method()

    scene.start_time = lptime.now()

def stop(scene):
    print(f"Memory left: {gc.mem_free()}")
    print("Oh? Time to go already? Bye bye from Test A!")

def update(scene):
    if lptime.now() - scene.start_time > scene.stay_time:
        scene_manager.load_scene("Test B")
        return


def extra_method():
    """This method should hopefully not get garbage collected, because
    the Scene Manager should add this to the Scene's locals after
    the Cartridge registration phase has finished.
    """

    print("I'm called from an extra method. Don't garbage collect me please!!")