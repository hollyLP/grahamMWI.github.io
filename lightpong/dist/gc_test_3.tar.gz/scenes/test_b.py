import lpp_scene_manager as scene_manager
import lpp_time as lptime
import gc


# Register the scene
scene_manager.register_scene("Test B")

test_global = 'This is a global value!'

def start(scene):
    print("\nHEY from Test B!")
    print(test_global)

    scene.start_time = lptime.now()
    scene.stay_time = 2

def stop(scene):
    print(f"About to free memory!\n\tCurrent: {gc.mem_free()}")
    gc.collect()
    print(f"\tAfter: {gc.mem_free()}")
    print("SEE YA from Test B!")

def update(scene):
   if lptime.now() - scene.start_time > scene.stay_time:
        scene_manager.load_scene("Test A")
        return
