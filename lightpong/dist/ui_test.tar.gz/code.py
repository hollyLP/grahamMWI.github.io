from lightpong import *

#
#   SETTINGS
#

# The framerate of the game
target_framerate = 120

# The name of the scene to start with
starting_scene = "Idle"


def setup():
    # Get the directory of the scenes folder
    scene_directory = __file__.replace('code.py', '') + '/scenes'

    # Initialize the library
    could_init: bool = initialize_lightponglib(scene_directory, 120)

    # If for some reason the initialization failed, then abort the setup
    if not could_init:
        return

    sound.set_volume(1)
    debug.log("Finished setup!\n")


    scene_manager.set_scene(starting_scene)
    

def loop():
    # Update the library repeatedly
    update_lightponglib()










setup()
while True:
    loop()