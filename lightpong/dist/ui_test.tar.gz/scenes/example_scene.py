from lightpong import *

class Scene(scene_base):

    # Constructor
    def __init__(self) -> None:
        super().__init__("ExampleScene")




    def start(self) -> None:
        return
        

    def stop(self) -> None:
        return

    def update(self) -> None:
        return


