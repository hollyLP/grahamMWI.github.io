from lightpong import *
import system_window_util as window
import gc

class Scene(scene_base):

    #
    #   Classes
    #

    class Choice():

        def __init__(self, scene_name, color) -> None:
            self.scene_name = scene_name
            self.color = color
            self.start_index = 0
            self.middle_index = 0
            self.end_index = 0
            self.is_selected = False
            self.last_selected_start_time = 0

        def setup_size(self, this_index, space_for_each_choice, half_width_of_choice) -> None:
            self.start_index = this_index * (space_for_each_choice)
            self.middle_index = self.start_index + (space_for_each_choice / 2)
            self.end_index = self.start_index + space_for_each_choice

            # Once we know the middle, fix up the start and end
            self.start_index = self.middle_index - half_width_of_choice
            self.end_index = self.middle_index + half_width_of_choice

            # Convert indexes
            self.start_index    = window.convert_index(self.start_index)
            self.middle_index   = window.convert_index(self.middle_index)
            self.end_index      = window.convert_index(self.end_index)

        def draw(self) -> None:

            if self.is_selected:
                choice_color = self.color
            else:
                choice_color = lightstrip.multiply_color_by_float(self.color, 0.2)

            lightstrip.draw_line(self.start_index, self.end_index, choice_color)

        def set_selected(self, is_selected: bool) -> None:
            self.is_selected = is_selected



    #
    #   Options
    #

    CHOICES = [
        Choice("UI Boot", lightstrip.get_color(255, 255, 0)),
        Choice("UI Sleep", lightstrip.get_color(255, 0, 255)),
        Choice("UI Shutdown", lightstrip.get_color(255, 255, 255)),
        Choice("UI Error Generic", lightstrip.get_color(255, 0, 0)),
        Choice("UI Error NoBoot", lightstrip.get_color(255, 0, 255)),
        Choice("UI Game Select", lightstrip.get_color(0, 0, 255)),
        Choice("UI Game Select Empty Slot", lightstrip.get_color(0, 100, 255)),
        Choice("UI Game Select Multi Slot", lightstrip.get_color(0, 255, 255)),
        Choice("UI Game Select Upload Game", lightstrip.get_color(0, 255, 100)),
        Choice("UI Notif Battery Charging", lightstrip.get_color(255, 0, 0)),
        Choice("UI Notif Battery Charging Simple", lightstrip.get_color(100, 0, 0)),
        Choice("UI Notif Battery Low", lightstrip.get_color(255, 100, 0)),
        Choice("UI Notif Battery Low Simple", lightstrip.get_color(100, 30, 0)),
        Choice("UI Notif Battery Low Critical", lightstrip.get_color(255, 255, 0)),
        Choice("UI Notif Comms Enabled", lightstrip.get_color(0, 255, 0)),
        Choice("UI Notif Comms Disabled", lightstrip.get_color(100, 255, 0)),
        Choice("UI Notif Comms Status", lightstrip.get_color(100, 0, 255)),
        Choice("UI Comms Setup", lightstrip.get_color(255, 0, 255)),
        Choice("UI Comms Request", lightstrip.get_color(255, 255, 0)),
        Choice("UI Notif Audio Level", lightstrip.get_color(0, 0, 255)),
        Choice("UI Notif Audio Muted", lightstrip.get_color(0, 100, 255)),
        Choice("UI Notif Audio Unmuted", lightstrip.get_color(0, 255, 255)),
    ]
    CHOICE_HALF_WIDTH = 2
    CHOICES_LEN = len(CHOICES)

    for x in range(0, CHOICES_LEN):     # Setup the choices defined above
        CHOICES[x].setup_size(x, lightstrip.length() / CHOICES_LEN, CHOICE_HALF_WIDTH)

    
    
    # Constructor
    def __init__(self) -> None:
        super().__init__("Idle")
        self.current_choice_index = 0                   # Which choice is currently selected  




    def start(self) -> None:
        gc.collect()
        for choice in Scene.CHOICES:
            choice.set_selected(False)
            
        Scene.CHOICES[self.current_choice_index].set_selected(True)  

        self.target_cursor_position = Scene.CHOICES[self.current_choice_index].middle_index
        self.actual_cursor_position = self.target_cursor_position                               

    def stop(self) -> None:
        return

    def update(self) -> None:
        self.handle_input()
        self.draw_scene()






    def handle_input(self) -> None:

        # Select the next choice if player 1 presses their button
        if input.player1().is_button_down():
            # Deselect the previous choice
            Scene.CHOICES[self.current_choice_index].set_selected(False)

            # Increment the choice index
            self.current_choice_index = (self.current_choice_index + 1) % Scene.CHOICES_LEN

            # Select the new choice
            Scene.CHOICES[self.current_choice_index].set_selected(True)

            # Update the target cursor to the new choice
            self.target_cursor_position = Scene.CHOICES[self.current_choice_index].middle_index
        # Confirm a choice if player 2 presses their button
        if input.player2().is_button_down():
            scene_manager.set_scene(Scene.CHOICES[self.current_choice_index].scene_name)


    def draw_scene(self) -> None:
        lightstrip.clear()

        self.draw_choices()

        lightstrip.show()

    def draw_choices(self) -> None:

        window.draw_window()

        for choice in Scene.CHOICES:
            choice.draw()

        self.actual_cursor_position = math.lerp(self.actual_cursor_position, self.target_cursor_position, time.delta() * 10)

        # Draw cursor
        lightstrip.draw_line_centered(self.actual_cursor_position, 1, lightstrip.get_color(0, 0, 0))
        lightstrip.draw_pixel(self.actual_cursor_position, lightstrip.get_color(255, 255, 255))

