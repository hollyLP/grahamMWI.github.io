from lightpong import *
import random

class Scene(scene_base):

    class State():
        SHORT_WAIT  = 0x00
        FILL_UP     = 0x01
        WAVER       = 0x02
        FADE_OUT    = 0x03

    class Particle():

        def __init__(self, position: int) -> None:
            self.lifetime = random.uniform(0.1, 0.5)
            self.start_time = time.now()
            self.position = position
            self.color = lightstrip.get_color(255, 255, 255)

        # Return true or false depending on if this particle is alive
        def is_alive(self) -> bool:
            return (time.now() - self.start_time) < self.lifetime

        def draw(self, brightness: float) -> None:
            time_since_started = time.now() - self.start_time
            color_mult = ease.cubic_out(1, 0, time_since_started / self.lifetime)

            color = lightstrip.multiply_color_by_float(self.color, color_mult * brightness)
            lightstrip.draw_pixel(self.position, color)

    class ParticleSystem():

        def __init__(self, spawn_rate: float) -> None:
            self.particles = []
            self.last_spawn_time = 0
            self.is_enabled = True
            self.brightness = 1

            self.spawn_rate = spawn_rate

        def set_enabled(self, is_enabled: bool) -> None:
            self.is_enabled = is_enabled

        def get_enabled(self) -> bool:
            return self.is_enabled

        def clear(self) -> None:
            self.particles.clear()

        def set_brightness(self, brightness: float) -> None:
            self.brightness = brightness

        def update(self) -> None:
            time_since_spawn = time.now() - self.last_spawn_time

            # If enough time has passed and we should spawn a new particle...
            if time_since_spawn > self.spawn_rate and self.is_enabled:
                time_since_spawn = time.now()

                position = random.randrange(0, lightstrip.length())
                self.particles.append(Scene.Particle(position))


            # Loop through each particle and look for dead ones
            to_remove = []
            for particle in self.particles:
                if not particle.is_alive():
                    to_remove.append(particle)

            # Remove any particles that are dead
            for dead_particle in to_remove:
                self.particles.remove(dead_particle)

        def draw(self) -> None:
            for particle in self.particles:
                particle.draw(self.brightness)

            


    #
    #   OPTIONS
    #

    INITIAL_WAIT_TIME = 0.25
    FILL_TIME = 0.4
    FILL_COLOR = lightstrip.get_color(200, 20, 200)
    WAVER_TIME = 0.25
    WAVER_SPEED = 10
    FADE_OUT_TIME = 2
    NEXT_SCENE = "UI Game Select"

    SOUND_BOOTUP = 'sounds/bootup.wav'

    PARTICLE_SYSTEM = ParticleSystem(0.3)

    # Constructor
    def __init__(self) -> None:
        super().__init__("UI Boot")




    def start(self) -> None:
        self.set_state(Scene.State.SHORT_WAIT)
        self.state_start_time = time.now()
        Scene.PARTICLE_SYSTEM.clear()
        Scene.PARTICLE_SYSTEM.set_brightness(1)
        Scene.PARTICLE_SYSTEM.set_enabled(False)
        
    def stop(self) -> None:
        return

    def update(self) -> None:
        lightstrip.clear()
        self.run_state_machine()
        Scene.PARTICLE_SYSTEM.update()
        Scene.PARTICLE_SYSTEM.draw()
        lightstrip.show()






    def set_state(self, new_state: State) -> None:
        self.state = new_state
        self.state_start_time = time.now()

        if new_state is Scene.State.FILL_UP:
            sound.play_file(Scene.SOUND_BOOTUP)
        elif new_state is Scene.State.WAVER:
            Scene.PARTICLE_SYSTEM.set_enabled(True)
        elif new_state is Scene.State.FADE_OUT:
            return
            Scene.PARTICLE_SYSTEM.set_enabled(False)

    def run_state_machine(self) -> None:

        if self.state is Scene.State.SHORT_WAIT:
            self.update_short_wait()
        elif self.state is Scene.State.FILL_UP:
            self.update_fill_up()
        elif self.state is Scene.State.WAVER:
            self.update_waver()
        elif self.state is Scene.State.FADE_OUT:
            self.update_fade_out()

    def update_short_wait(self) -> None:
        local_time = time.now() - self.state_start_time

        if local_time > Scene.INITIAL_WAIT_TIME:
            self.set_state(Scene.State.FILL_UP)

    def update_fill_up(self) -> None:
        local_time = time.now() - self.state_start_time

        fill_lerp = local_time / Scene.FILL_TIME
        width = ease.cubic_in(0, lightstrip.length() / 2, fill_lerp)

        lightstrip.draw_line_centered(lightstrip.length() / 2, width, Scene.FILL_COLOR)

        if fill_lerp > 1:
            self.set_state(Scene.State.WAVER)

    def update_waver(self) -> None:
        local_time = time.now() - self.state_start_time
        
        color_amount = ease.linear(1, 0.6, math.sine_wave_abs(local_time * Scene.WAVER_SPEED))
        self.waver_color = lightstrip.multiply_color_by_float(Scene.FILL_COLOR, color_amount)
        lightstrip.draw_fill(self.waver_color)

        if local_time > Scene.WAVER_TIME:
            self.set_state(Scene.State.FADE_OUT)

    def update_fade_out(self) -> None:
        local_time = time.now() - self.state_start_time

        color_amount = ease.quad_out(1, 0, local_time / Scene.FADE_OUT_TIME)
        Scene.PARTICLE_SYSTEM.set_brightness(color_amount)
        lightstrip.draw_fill(lightstrip.multiply_color_by_float(self.waver_color, color_amount))

        if local_time > Scene.FADE_OUT_TIME:
            scene_manager.set_scene(Scene.NEXT_SCENE)


        
