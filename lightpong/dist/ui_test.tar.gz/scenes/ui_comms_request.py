from lightpong import *
import system_window_util as window

class Scene(scene_base):

    #
    #   OPTIONS
    #

    COLOR_OPTION_YES = lightstrip.get_color(0, 255, 0)
    COLOR_OPTION_NO = lightstrip.get_color(255, 0, 0)
    OPTION_HWIDTH = 8
    OPTION_EXPAND_TIME = 0.5
    OPTION_EXPAND_FINISH_TIME = 0.5

    COLOR_WIFI_NORMAL = lightstrip.get_color(0, 10, 255)
    WIFI_BAND_SPEED_DISCONNECTED = 0.5

    FADE_IN_TIME = 0.3

    NEXT_SCENE = "Idle"



    # Constructor
    def __init__(self) -> None:
        super().__init__("UI Comms Request")




    def start(self) -> None:
        self.scene_start_time = time.now()
        self.target_cursor_position = lightstrip.length() / 2
        self.actual_cursor_position = self.target_cursor_position
        self.selected_option = -1
        self.option_expanding = None
        self.expand_start_time = -1
        
    def stop(self) -> None:
        return

    def update(self) -> None:
        local_time = time.now() - self.scene_start_time

        brightness = 0
        if local_time < Scene.FADE_IN_TIME:
            brightness = ease.linear(0, 1, local_time / Scene.FADE_IN_TIME)
        else:
            brightness = 1

            if input.player2().is_button_down() and self.selected_option != -1:
                self.option_expanding = self.selected_option
                self.expand_start_time = local_time

        



        lightstrip.clear()

        self.draw_waves(local_time, brightness)
        self.draw_options(local_time, brightness)

        if self.option_expanding is not None:
            self.draw_option_expanding(local_time, brightness)

        window.draw_window(brightness)

        lightstrip.show()






    def draw_waves(self, local_time: float, brightness: float) -> None:

        offsets = [0.0, 0.25, 0.5, 0.75]
        middle = lightstrip.length() / 2

        base_wifi_color = Scene.COLOR_WIFI_NORMAL
        for offset in offsets:

            lerp_time_unmodded = math.clamp(0, 99999999999, (local_time * Scene.WIFI_BAND_SPEED_DISCONNECTED + offset) - 1)

            if int(lerp_time_unmodded) % 2 != 1:

                lerp_time = lerp_time_unmodded % 1
                index_lerp = ease.linear(0, lightstrip.length() / 4, lerp_time)
                width = ease.linear(0, 4, lerp_time)
                index_L = middle - index_lerp
                index_R = middle + index_lerp

                waver_amount = ease.linear(1, 0.5, math.sine_wave_abs((local_time + offset) * 20))
                wifi_color = lightstrip.multiply_color_by_float(base_wifi_color, ease.linear(1, 0, lerp_time) * brightness * waver_amount)
                lightstrip.draw_line_centered(index_L, width, wifi_color)
                lightstrip.draw_line_centered(index_R, width, wifi_color)

        middle_waver_amount = ease.linear(1, 0.5, math.sine_wave_abs(local_time * 10))
        lightstrip.draw_line_centered(middle, 1, lightstrip.multiply_color_by_float(base_wifi_color, brightness * middle_waver_amount))

    def draw_options(self, local_time: float, brightness: float) -> None:

        if input.player1().is_button_down():
            if self.selected_option is -1:
                self.selected_option = 0
            else:
                self.selected_option = (self.selected_option + 1) % 2

        index_option_no     = math.lerp(window.view_start(), window.view_end(), 0.1)
        index_option_yes    = math.lerp(window.view_start(), window.view_end(), 0.9)
        option_hwidth = Scene.OPTION_HWIDTH

        brightness_option_no = 0.2
        brightness_option_yes = 0.2

        if self.selected_option is 0:
            brightness_option_no = 1
            self.target_cursor_position = index_option_no
        elif self.selected_option is 1:
            brightness_option_yes = 1
            self.target_cursor_position = index_option_yes

        self.actual_cursor_position = math.lerp(self.actual_cursor_position, self.target_cursor_position, time.delta() * 10)

        lightstrip.draw_line_centered(index_option_no, option_hwidth, lightstrip.multiply_color_by_float(Scene.COLOR_OPTION_NO, brightness_option_no))
        lightstrip.draw_line_centered(index_option_yes, option_hwidth, lightstrip.multiply_color_by_float(Scene.COLOR_OPTION_YES, brightness_option_yes))

        if self.selected_option is not -1:
            # Draw cursor
            lightstrip.draw_line_centered(self.actual_cursor_position, 1, lightstrip.get_color(0, 0, 0))
            lightstrip.draw_pixel(self.actual_cursor_position, lightstrip.get_color(255, 255, 255))

    def draw_option_expanding(self, local_time: float, brightness: float) -> None:
        expand_time = local_time - self.expand_start_time
        lerp_time = ease.quad_in(0, 1, expand_time / Scene.OPTION_EXPAND_TIME)

        index_middle = lightstrip.length() / 2
        color_option = Scene.COLOR_WIFI_NORMAL

        # Set the middle index depending on which option is expanding
        if self.option_expanding is 0:
            index_middle    = math.lerp(0, lightstrip.length(), 0.1)
            color_option    = Scene.COLOR_OPTION_NO
        elif self.option_expanding is 1:
            index_middle    = math.lerp(0, lightstrip.length(), 0.9)
            color_option    = Scene.COLOR_OPTION_YES


        if lerp_time < 1:

            index_left = math.lerp(index_middle, 0, lerp_time)
            index_right = math.lerp(index_middle, lightstrip.length() - 1, lerp_time)

            lightstrip.draw_line(index_middle, index_left, color_option)
            lightstrip.draw_line(index_middle, index_right, color_option)

        else:
            fade_time = expand_time - Scene.OPTION_EXPAND_TIME

            fill_color = lightstrip.multiply_color_by_float(color_option, ease.linear(1, 0, fade_time / Scene.OPTION_EXPAND_FINISH_TIME))
            lightstrip.draw_fill(fill_color)

            if expand_time > Scene.OPTION_EXPAND_TIME + Scene.OPTION_EXPAND_FINISH_TIME:
                scene_manager.set_scene(Scene.NEXT_SCENE)

