from lightpong import *
import system_window_util as window

class Scene(scene_base):

    #
    #   OPTIONS
    #

    COLOR_WIFI_SETUP = lightstrip.get_color(255, 255, 0)
    COLOR_BACKGROUND = lightstrip.multiply_color_by_float(lightstrip.get_color(0, 100, 255), 0.2)

    WIFI_BAND_SPEED_SETUP = (130 / 60) / 2
    WIFI_BAND_SPEED_BG = (130 / 60) / 8

    FADE_IN_TIME = 0.6

    SOUND_LOOP_TIME = 1.845
    SOUND_COMMS_SETUP = 'sounds/comms_searching.wav'

    NEXT_SCENE = "Idle"



    # Constructor
    def __init__(self) -> None:
        super().__init__("UI Comms Setup")




    def start(self) -> None:
        self.scene_start_time = time.now()
        self.next_play_time = time.now()
        
    def stop(self) -> None:
        return

    def update(self) -> None:
        local_time = time.now() - self.scene_start_time

        if time.now() >= self.next_play_time:
            self.next_play_time = time.now() + Scene.SOUND_LOOP_TIME
            sound.play_file(Scene.SOUND_COMMS_SETUP)

        brightness = 0
        if local_time < Scene.FADE_IN_TIME:
            brightness = ease.linear(0, 1, local_time / Scene.FADE_IN_TIME)
        else:
            brightness = 1
            if input.player1().is_button_down() or input.player2().is_button_down():
                scene_manager.set_scene(Scene.NEXT_SCENE)


        lightstrip.clear()


        offsets = [0.0, 0.5]
        middle = lightstrip.length() / 2

        lightstrip.draw_fill(lightstrip.multiply_color_by_float(
            Scene.COLOR_BACKGROUND, 
            ease.quad_in(
                0, 1,
                math.sine_wave_abs((local_time - 2) * math.pi * Scene.WIFI_BAND_SPEED_BG))
            )
        )

        base_wifi_color = Scene.COLOR_WIFI_SETUP
        for offset in offsets:
            lerp_time = math.clamp(0, 99999999999, (local_time * Scene.WIFI_BAND_SPEED_SETUP + offset) - 1) % 1 
            index_lerp = ease.linear(0, lightstrip.length() / 2.5, lerp_time)
            width = ease.linear(0, 9, lerp_time)
            index_L = middle - index_lerp
            index_R = middle + index_lerp

            waver_amount = ease.linear(1, 0.3, math.sine_wave_abs((local_time + offset) * 20))
            wifi_color = lightstrip.multiply_color_by_float(base_wifi_color, ease.linear(1, 0, lerp_time) * brightness * waver_amount)
            lightstrip.draw_line_centered(index_L, width, wifi_color)
            lightstrip.draw_line_centered(index_R, width, wifi_color)

        middle_waver_amount = ease.linear(1, 0.7, math.square_wave(local_time * 40))
        lightstrip.draw_line_centered(middle, 1, lightstrip.multiply_color_by_float(base_wifi_color, brightness * middle_waver_amount))

        window.draw_window(brightness)

        lightstrip.show()