from lightpong import *
import system_window_util as window

class Scene(scene_base):

    #
    #   OPTIONS
    #

    COLOR_BACKGROUND = lightstrip.get_color(20, 0, 0)
    COLOR_ERROR = lightstrip.get_color(200, 0, 0)

    BACKGROUND_WAVER_SPEED = 2
    ERROR_WAVER_SPEED = 2
    ERROR_HWIDTH = 20 / 2
    ERROR_ANIM_DELAY = 2
    ERROR_ANIM_TIME = 0.15
    ERROR_FLICKER_TIME = 0.08
    ERROR_FLICKER_COUNT = 2 * 2

    FADE_IN_TIME = 0.2

    NEXT_SCENE = "UI Game Select"



    # Constructor
    def __init__(self) -> None:
        super().__init__("UI Error Generic")




    def start(self) -> None:
        self.scene_start_time = time.now()
        
    def stop(self) -> None:
        return

    def update(self) -> None:
        local_time = time.now() - self.scene_start_time

        brightness = 0
        if local_time < Scene.FADE_IN_TIME:
            brightness = ease.linear(0, 1, local_time / Scene.FADE_IN_TIME)
        else:
            brightness = 1
            
            if input.player1().is_button_down() or input.player2().is_button_down():
                scene_manager.set_scene(Scene.NEXT_SCENE)



        lightstrip.clear()

        self.draw_background(local_time, brightness)
        self.draw_error(local_time, brightness)

        window.draw_window()

        lightstrip.show()

    # Draw a wavering red background
    def draw_background(self, local_time: float, brightness: float) -> None:
        waver_lerp = ease.linear(0.5, 1, math.sine_wave_abs(local_time * Scene.BACKGROUND_WAVER_SPEED))
        background_color = lightstrip.multiply_color_by_float(Scene.COLOR_BACKGROUND, waver_lerp * brightness)

        lightstrip.draw_line(window.view_start(), window.view_end(), background_color)

    # Draw a graphic in the middle of the strip representing the error
    def draw_error(self, local_time: float, brightness: float) -> None:
        error_hwidth = ease.spring(0, Scene.ERROR_HWIDTH, (local_time / Scene.ERROR_ANIM_TIME) - Scene.ERROR_ANIM_DELAY)

        # Transform the current time into a value incrementing every ERROR_FLICKER_TIME seconds
        flicker_counter = round(math.clamp(0, Scene.ERROR_FLICKER_COUNT + 1, (local_time / Scene.ERROR_FLICKER_TIME) - Scene.ERROR_ANIM_DELAY))

        # If we should actually draw the graphic
        if error_hwidth != 0:

            # If we should flicker the brightness this frame...
            if flicker_counter % 2 == 0:
                brightness = brightness * 0.7

            # Calculate the error waver
            error_hwidth = ease.linear(error_hwidth, error_hwidth + 5, math.sine_wave_abs(local_time * Scene.ERROR_WAVER_SPEED))

            # Draw the graphic
            error_color = lightstrip.multiply_color_by_float(Scene.COLOR_ERROR, brightness)
            lightstrip.draw_line_centered(window.view_middle(), error_hwidth, error_color)