from lightpong import *
import system_window_util as window

class Scene(scene_base):

    #
    #   OPTIONS
    #

    COLOR_ERROR = lightstrip.get_color(255, 0, 0)

    ERROR_HWIDTH = 10 / 2
    FLICKER_TIME = 0.5
    NEXT_SCENE = "Idle"

    STAY_TIME = 6


    # Constructor
    def __init__(self) -> None:
        super().__init__("UI Error NoBoot")




    def start(self) -> None:
        self.scene_start_time = time.now()
        
    def stop(self) -> None:
        return

    def update(self) -> None:
        local_time = time.now() - self.scene_start_time

        if local_time > Scene.STAY_TIME:
            scene_manager.set_scene(Scene.NEXT_SCENE)




        lightstrip.clear()

        self.draw_error(local_time, 0.2)

        lightstrip.show()

    # Draw a graphic in the middle of the strip representing the error
    def draw_error(self, local_time: float, brightness: float) -> None:

        flicker_ticker = int(local_time / Scene.FLICKER_TIME) % 2
        if flicker_ticker == 0:
            brightness = brightness * 0.5

        error_color = lightstrip.multiply_color_by_float(Scene.COLOR_ERROR, brightness)
        lightstrip.draw_line_centered(window.view_middle(),                             Scene.ERROR_HWIDTH,     error_color)
        lightstrip.draw_line_centered(window.view_middle() - Scene.ERROR_HWIDTH - 4,    1,                      error_color)
        lightstrip.draw_line_centered(window.view_middle() + Scene.ERROR_HWIDTH + 4,    1,                      error_color)
        lightstrip.draw_line_centered(window.view_middle() - Scene.ERROR_HWIDTH - 8,    0,                      error_color)
        lightstrip.draw_line_centered(window.view_middle() + Scene.ERROR_HWIDTH + 8,    0,                      error_color)
