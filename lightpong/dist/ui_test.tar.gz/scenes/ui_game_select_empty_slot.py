from lightpong import *
import system_window_util as window

class Scene(scene_base):

    class GameDemo():

        def setup(self, bounds_start: int, bounds_end: int) -> None:
            self.bounds_start = bounds_start
            self.bounds_end = bounds_end
            self.bounds_middle = math.lerp(bounds_start, bounds_end, 0.5)
            self.is_enabled = True
            self.brightness = 1
            self.time = time.now()
            self.delta = time.delta()

        def set_enabled(self, is_enabled: bool) -> None:
            self.is_enabled = is_enabled

            if is_enabled:
                self.brightness = 1
            else:
                self.brightness = 0.2

        def set_super_disabled(self) -> None:
            self.is_enabled = False
            self.brightness = 0

        def get_enabled(self) -> bool:
            return self.is_enabled


        def start(self) -> None:
            return

        def draw(self) -> None:
            if self.is_enabled:
                self.time = self.time + time.delta()
                self.delta = time.delta()
                self.brightness = ease.linear(1, 0.7, math.sine_wave_abs(self.time * 7))
            else:
                self.delta = 0
            self.on_draw()

        def on_draw(self) -> None:
            return

    class GameDemo_LightTennis(GameDemo):

        COLOR_BACKGROUND    = lightstrip.get_color(20, 0, 20)
        COLOR_NET           = lightstrip.get_color(0, 0, 255)
        COLOR_NET_OUTLINE   = lightstrip.get_color(0, 0, 0)
        COLOR_BALL          = lightstrip.get_color(255, 255, 255)

        NET_WIDTH = 2
        BALL_SPEED = 40

        def start(self) -> None:
            self.ball_position = self.bounds_middle
            self.ball_speed = self.BALL_SPEED

            self.ball_min = math.lerp(self.bounds_start, self.bounds_middle, 0.25)
            self.ball_max = math.lerp(self.bounds_end, self.bounds_middle, 0.25)
            self.playerA_last_hit_time = 0
            self.playerB_last_hit_time = 0

        def on_draw(self) -> None:
            
            COLOR_BACKGROUND_CORRECT    = lightstrip.multiply_color_by_float(self.COLOR_BACKGROUND, self.brightness)
            COLOR_NET_CORRECT           = lightstrip.multiply_color_by_float(self.COLOR_NET, self.brightness)
            COLOR_NET_OUTLINE_CORRECT   = lightstrip.multiply_color_by_float(self.COLOR_NET_OUTLINE, self.brightness)
            COLOR_BALL_CORRECT          = lightstrip.multiply_color_by_float(self.COLOR_BALL, self.brightness)

            self.ball_position = self.ball_position + (self.ball_speed * self.delta)

            if self.ball_position > self.ball_max:
                self.ball_position = self.ball_max
                self.ball_speed = self.ball_speed * -1
                self.playerB_last_hit_time = self.time

            elif self.ball_position < self.ball_min:
                self.ball_position = self.ball_min
                self.ball_speed = self.ball_speed * -1
                self.playerA_last_hit_time = self.time

            # Draw background
            time_since_playerA_hit = self.time - self.playerA_last_hit_time
            time_since_playerB_hit = self.time - self.playerB_last_hit_time
            lightstrip.draw_line(
                self.bounds_start, 
                self.bounds_middle,
                lightstrip.multiply_color_by_float(COLOR_BACKGROUND_CORRECT, math.lerp(5, 1, math.clamp(0, 1, time_since_playerA_hit * 6)))
            )
            lightstrip.draw_line(
                self.bounds_middle, 
                self.bounds_end,
                lightstrip.multiply_color_by_float(COLOR_BACKGROUND_CORRECT, math.lerp(5, 1, math.clamp(0, 1, time_since_playerB_hit * 6)))
            )

            # Draw net
            lightstrip.draw_line_centered(self.bounds_middle, self.NET_WIDTH, COLOR_NET_OUTLINE_CORRECT)
            lightstrip.draw_pixel(self.bounds_middle, COLOR_NET_CORRECT)

            # Draw ball
            lightstrip.draw_pixel(self.ball_position, COLOR_BALL_CORRECT)



    class GameDemo_TugOfWar(GameDemo):

        COLOR_PLAYERA           = lightstrip.get_color(255, 0, 100)
        COLOR_PLAYERB           = lightstrip.get_color(0, 100, 255)
        COLOR_MIDDLE            = lightstrip.get_color(255, 255, 255)
        COLOR_MIDDLE_OUTLINE    = lightstrip.get_color(0, 0, 0)

        WAVE_SPEED = 7
        WAVE_JITTER_SPEED = 30

        def on_draw(self) -> None:
            COLOR_PLAYERA_CORRECT           = lightstrip.multiply_color_by_float(self.COLOR_PLAYERA, self.brightness)
            COLOR_PLAYERB_CORRECT           = lightstrip.multiply_color_by_float(self.COLOR_PLAYERB, self.brightness)
            COLOR_MIDDLE_CORRECT            = lightstrip.multiply_color_by_float(self.COLOR_MIDDLE, self.brightness)
            COLOR_MIDDLE_OUTLINE_CORRECT    = lightstrip.multiply_color_by_float(self.COLOR_MIDDLE_OUTLINE, self.brightness)


            current_middle = self.bounds_middle + ease.linear(5, -5, math.sine_wave_abs(self.time * self.WAVE_SPEED))
            current_middle = current_middle + ease.linear(2, -2, math.sine_wave_abs(self.time * self.WAVE_JITTER_SPEED))
            
            # Draw the left and right lines
            lightstrip.draw_line(self.bounds_start, current_middle, COLOR_PLAYERA_CORRECT)
            lightstrip.draw_line(current_middle, self.bounds_end, COLOR_PLAYERB_CORRECT)

            # Draw the middle net
            lightstrip.draw_line_centered(current_middle, 2, COLOR_MIDDLE_OUTLINE_CORRECT)
            lightstrip.draw_pixel(current_middle, COLOR_MIDDLE_CORRECT)

    class GameDemo_Empty(GameDemo):

        COLOR_BACKGROUND = lightstrip.get_color(10, 10, 10)

        def start(self) -> None:
            self.last_click_time = 0

        def click(self) -> None:
            self.last_click_time = time.now()

        def on_draw(self) -> None:
            
            COLOR_BACKGROUND_CORRECT = lightstrip.multiply_color_by_float(self.COLOR_BACKGROUND, self.brightness)

            time_since_click = time.now() - self.last_click_time
            if time_since_click < 1:
                COLOR_BACKGROUND_CORRECT = lightstrip.multiply_color_by_float(
                    COLOR_BACKGROUND_CORRECT,
                    ease.linear(1, 0.5, math.square_wave_abs(self.time * 30))
                )

            lightstrip.draw_line(self.bounds_start, self.bounds_end, COLOR_BACKGROUND_CORRECT)









    #
    #   OPTIONS
    #

    ENTRANCE_TIME = 0.5
    ENTRANCE_COLOR = lightstrip.get_color(0, 0, 0)
    EXIT_TIME = 0.5
    EXIT_COLOR = lightstrip.get_color(0, 0, 0)

    SOUND_ENTER     = 'sounds/game_select_enter.wav'    # Plays when this UI is entered
    SOUND_LAUNCH    = 'sounds/game_select_launch.wav'   # Plays when a game is launched
    SOUND_TICK      = 'sounds/game_select_tick.wav'     # Plays when the user scrolls through the UI
    SOUND_EMPTY     = 'sounds/game_select_empty.wav'    # Plays when the user tries to launch an empty slot

    GAME_SPACING = 3
    
    NEXT_SCENE = "Idle"

    # An array of games to display
    GAMES_TO_DISPLAY = [
        GameDemo_Empty(),
        GameDemo_TugOfWar(),
        GameDemo_Empty()
    ]
    GAMES_TO_DISPLAY_LEN = len(GAMES_TO_DISPLAY)

    # Setup each game to display
    for index in range(GAMES_TO_DISPLAY_LEN):
        # Get the start and stop bounds for each game
        bounds_start = index * (lightstrip.length() / GAMES_TO_DISPLAY_LEN) + GAME_SPACING
        bounds_end = (index + 1) * (lightstrip.length() / GAMES_TO_DISPLAY_LEN) - GAME_SPACING

        # Setup this game's demo
        GAMES_TO_DISPLAY[index].setup(window.convert_index(bounds_start), window.convert_index(bounds_end))

    # Constructor
    def __init__(self) -> None:
        super().__init__("UI Game Select Empty Slot")




    def start(self) -> None:
        self.selected_game = 0
        self.scene_start_time = time.now()
        self.can_select = True
        self.draw_fade_out = False
        self.fade_out_start_time = 0

        for demo in Scene.GAMES_TO_DISPLAY:
            demo.set_enabled(False)
            demo.start()

        Scene.GAMES_TO_DISPLAY[self.selected_game].set_enabled(True)

        sound.play_file(Scene.SOUND_ENTER)
        
    def stop(self) -> None:
        return

    def update(self) -> None:
        self.handle_input()
        self.draw()

    def handle_input(self) -> None:
        # If we want to scroll to another game
        if input.player1().is_button_down() and self.can_select:
            # Deselect the previous choice
            Scene.GAMES_TO_DISPLAY[self.selected_game].set_enabled(False)

            # Increment the choice index
            self.selected_game = (self.selected_game + 1) % Scene.GAMES_TO_DISPLAY_LEN

            # Select the new choice
            Scene.GAMES_TO_DISPLAY[self.selected_game].set_enabled(True)

            sound.play_file(Scene.SOUND_TICK)

        # If we want to launch the currently selected game...
        if input.player2().is_button_down() and self.can_select:
            if self.selected_game == 2 or self.selected_game == 0:
                Scene.GAMES_TO_DISPLAY[self.selected_game].click()
                sound.play_file(Scene.SOUND_EMPTY)
            else:
                self.can_select = False
                self.draw_fade_out = True
                self.fade_out_start_time = time.now()

                # Super disable the others
                for index in range(0, Scene.GAMES_TO_DISPLAY_LEN):
                    if not index == self.selected_game:
                        Scene.GAMES_TO_DISPLAY[index].set_super_disabled()

                sound.play_file(Scene.SOUND_LAUNCH)

    def draw(self) -> None:
        lightstrip.clear()

        for demo in Scene.GAMES_TO_DISPLAY:
            demo.draw()
        
        # Draw entrance overlay
        time_since_entrance = time.now() - self.scene_start_time

        if time_since_entrance < Scene.ENTRANCE_TIME:
            entrance_overlay_left_start = 0
            entrance_overlay_left_end = ease.cubic_out(lightstrip.length() / 2, entrance_overlay_left_start, time_since_entrance / Scene.ENTRANCE_TIME)
            entrance_overlay_right_start = lightstrip.length()
            entrance_overlay_right_end = ease.cubic_out(lightstrip.length() / 2, entrance_overlay_right_start, time_since_entrance / Scene.ENTRANCE_TIME)
            lightstrip.draw_line(entrance_overlay_left_start, entrance_overlay_left_end, Scene.ENTRANCE_COLOR)
            lightstrip.draw_line(entrance_overlay_right_start, entrance_overlay_right_end, Scene.ENTRANCE_COLOR)

        if self.draw_fade_out:
            time_since_fadeout_start = time.now() - self.fade_out_start_time - 0.25
            half_width = ease.cubic_in(0, lightstrip.length() / 2, time_since_fadeout_start / Scene.ENTRANCE_TIME)

            lightstrip.draw_line_centered(Scene.GAMES_TO_DISPLAY[self.selected_game].bounds_middle, half_width, Scene.EXIT_COLOR)

            if time_since_fadeout_start > Scene.EXIT_TIME + 1:
                scene_manager.set_scene(Scene.NEXT_SCENE)

        window.draw_window()

        lightstrip.show()


        
