from lightpong import *
import random
import system_window_util as window


class Scene(scene_base):

    #
    #   OPTIONS
    #

    COLOR_CAPS = lightstrip.get_color(50, 50, 50)
    COLOR_BAR = lightstrip.multiply_color_by_float(lightstrip.get_color(255, 255, 255), 0.2)
    COLOR_BAR_END = lightstrip.get_color(10, 255, 255)

    CAP_LENGTH = 4
    BAR_END_HWIDTH = 2
    BAR_DOT_SPACING = 7
    BAR_DOT_HWIDTH = 2

    FADE_IN_TIME = 0.2
    FADE_STAY_TIME = 2
    FADE_OUT_TIME = 0.2

    NEXT_SCENE = "Idle"


    # Constructor
    def __init__(self) -> None:
        super().__init__("UI Notif Audio Level")




    def start(self) -> None:
        self.scene_start_time = time.now()
        self.last_change_time = 0
        self.current_volume = 0.5
        self.target_volume = random.uniform(0, 1)
        
    def stop(self) -> None:
        return

    def update(self) -> None:
        local_time = time.now() - self.scene_start_time

        brightness = 0
        if local_time < Scene.FADE_IN_TIME:
            brightness = ease.linear(0, 1, local_time / Scene.FADE_IN_TIME)
        else:
            brightness = 1

            if local_time - self.last_change_time > 1:
                if (local_time - self.last_change_time - 1) < Scene.FADE_IN_TIME + Scene.FADE_STAY_TIME + Scene.FADE_OUT_TIME:
                    brightness = ease.linear(1, 0, (local_time - self.last_change_time - 1 - Scene.FADE_IN_TIME - Scene.FADE_STAY_TIME) / Scene.FADE_OUT_TIME)
                else:
                    scene_manager.set_scene(Scene.NEXT_SCENE)
                    return



        if input.player1().is_button_down():
            self.target_volume = random.uniform(0, 1)
            self.last_change_time = local_time

        lightstrip.clear()

        self.draw_caps(local_time, brightness)
        self.draw_volume_bar(local_time, brightness)
        window.draw_window(brightness)

        lightstrip.show()

    def draw_caps(self, local_time: float, brightness: float) -> None:
        cap_color = lightstrip.multiply_color_by_float(Scene.COLOR_CAPS, brightness)
        lightstrip.draw_line(0, Scene.CAP_LENGTH, cap_color)
        lightstrip.draw_line(lightstrip.length() - 1, lightstrip.length() - 1 - Scene.CAP_LENGTH, cap_color)

    def draw_volume_bar(self, local_time: float, brightness: float) -> None:
        #if local_time > Scene.FADE_IN_TIME:
        self.current_volume = math.lerp(self.current_volume, self.target_volume, time.delta() * 10)

        # Calculate the min length, max length, and actual end of the volume bar
        bar_min = Scene.CAP_LENGTH + 3
        bar_max = lightstrip.length() - 1 - Scene.CAP_LENGTH - 3
        bar_end = math.lerp(bar_min, bar_max, self.current_volume)

        bar_color = lightstrip.multiply_color_by_float(Scene.COLOR_BAR, brightness)


        bar_bg_color = lightstrip.multiply_color_by_float(bar_color, ease.linear(0.3, 0.1, math.sine_wave_abs(local_time * 5)))
        #lightstrip.draw_line(bar_min, bar_end, bar_bg_color)

        # Draw the bar
        last_index = 0
        for index in range(bar_min, round(bar_end), Scene.BAR_DOT_SPACING):
            last_index = index
            new_color = self.get_bar_color(index, brightness)
            lightstrip.draw_line_centered(index, Scene.BAR_DOT_HWIDTH, new_color)

        #final_bar_color = lightstrip.multiply_color_by_float(Scene.COLOR_BAR_END, ease.linear(1, 0.5, math.sine_wave_abs(local_time * 10)) * brightness)
        #lightstrip.draw_line_centered(last_index, Scene.BAR_END_HWIDTH, final_bar_color)

    def get_bar_color(self, index: int, brightness: float) -> lightstrip.Color:
        lerp_time = math.clamp01(index / lightstrip.length())

        output_color = Scene.COLOR_BAR
        if lerp_time < 0.55:
            output_color = lightstrip.get_color(0, 255, 0)
        elif lerp_time < 0.8:
            output_color = lightstrip.get_color(255, 255, 0)
        else:
            output_color = lightstrip.get_color(255, 0, 0)

        return lightstrip.multiply_color_by_float(output_color, brightness) 