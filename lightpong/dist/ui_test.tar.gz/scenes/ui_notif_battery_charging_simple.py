from lightpong import *
import system_window_util as window

class Scene(scene_base):


    #
    #   OPTIONS
    #

    COLOR_BATTERY_CAP = lightstrip.get_color(100, 100, 100)
    COLOR_BATTERY_FULL = lightstrip.get_color(20, 255, 20)
    COLOR_BATTERY_BACKGROUND = lightstrip.get_color(10, 10, 10)

    BATTERY_HWIDTH = 20 / 2
    BATTERY_CAP_LENGTH = 1
    BATTERY_SECTION_OFFSET = 2
    BATTERY_MIDDLE_INDEX = lightstrip.length() / 2
    BATTERY_START_INDEX = BATTERY_MIDDLE_INDEX - BATTERY_HWIDTH
    BATTERY_END_INDEX = BATTERY_MIDDLE_INDEX + BATTERY_HWIDTH

    BATTERY_SECTION_FILL_TIME = 1 / 4

    
    STAY_TIME = 3

    NEXT_SCENE = "Idle"


    # Constructor
    def __init__(self) -> None:
        super().__init__("UI Notif Battery Charging Simple")




    def start(self) -> None:
        self.scene_start_time = time.now()
        
    def stop(self) -> None:
        return

    def update(self) -> None:
        local_time = time.now() - self.scene_start_time

        if local_time > Scene.STAY_TIME:
            scene_manager.set_scene(Scene.NEXT_SCENE)
            return





        lightstrip.clear()

        self.draw_battery_caps(local_time, 0.3)
        self.draw_battery_contents(local_time, 0.3)
        
        lightstrip.show()


    # Draw the small caps and the start end end of the battery
    def draw_battery_caps(self, local_time: float, brightness: float) -> None:

        color_battery_cap = lightstrip.multiply_color_by_float(Scene.COLOR_BATTERY_CAP, brightness)
        lightstrip.draw_line(
            Scene.BATTERY_START_INDEX - 1, 
            Scene.BATTERY_START_INDEX - 1 - Scene.BATTERY_CAP_LENGTH, 
            color_battery_cap
        )
        lightstrip.draw_line(
            Scene.BATTERY_END_INDEX + 1, 
            Scene.BATTERY_END_INDEX + 1 + Scene.BATTERY_CAP_LENGTH, 
            color_battery_cap
        )

    # Draw what should be inside the battery (in this case, an animation showing the bars filling up)
    def draw_battery_contents(self, local_time: float, brightness: float) -> None:

        sector_top_start, sector_top_end        = self.get_battery_section(0)   # Get the indexes for the top battey line
        sector_middle_start, sector_middle_end  = self.get_battery_section(1)   # Get the indexes for the middle battery line
        sector_bottom_start, sector_bottom_end  = self.get_battery_section(2)   # Get the indexes for the bottom battery line

        color_battery_background = lightstrip.multiply_color_by_float(Scene.COLOR_BATTERY_BACKGROUND, brightness)   # Create a simple background color
        color_battery_full = lightstrip.multiply_color_by_float(Scene.COLOR_BATTERY_FULL, brightness)               # Create a color to display as powered        
        
        number_of_sections_to_draw = int(local_time / Scene.BATTERY_SECTION_FILL_TIME) % 4

        color_section_bottom = color_battery_background
        color_section_middle = color_battery_background
        color_section_top = color_battery_background

        if number_of_sections_to_draw > 0:
            color_section_bottom = color_battery_full
        if number_of_sections_to_draw > 1:
            color_section_middle = color_battery_full
        if number_of_sections_to_draw > 2:
            color_section_top = color_battery_full

        lightstrip.draw_line(sector_bottom_start, sector_bottom_end, color_section_bottom)
        lightstrip.draw_line(sector_middle_start, sector_middle_end, color_section_middle)
        lightstrip.draw_line(sector_top_start, sector_top_end, color_section_top)




    # Return the start and end sections for this part of the battery
    def get_battery_section(self, index: int) -> tuple:
        section_start   = math.lerp(Scene.BATTERY_START_INDEX, Scene.BATTERY_END_INDEX, (index) * (1 / 3))          # Get the start position for this index
        section_end     = math.lerp(Scene.BATTERY_START_INDEX, Scene.BATTERY_END_INDEX, (index + 1) * (1 / 3))      # Get the end position for this index
        return (section_start + Scene.BATTERY_SECTION_OFFSET, section_end - Scene.BATTERY_SECTION_OFFSET)