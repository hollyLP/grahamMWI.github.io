from lightpong import *
import system_window_util as window

class Scene(scene_base):

    #
    #   OPTIONS
    #

    COLOR_BATTERY_CAP = lightstrip.get_color(100, 100, 100)
    COLOR_BATTERY_FULL = lightstrip.get_color(20, 255, 20)
    COLOR_BATTERY_EMPTY = lightstrip.get_color(255, 0, 0)
    COLOR_BATTERY_BACKGROUND = lightstrip.get_color(10, 10, 10)

    SOUND_LOW_BATTERY = 'sounds/low_battery.wav'

    BATTERY_HWIDTH = 40 / 2
    BATTERY_CAP_LENGTH = 3
    BATTERY_SECTION_OFFSET = 2
    BATTERY_MIDDLE_INDEX = lightstrip.length() / 2
    BATTERY_START_INDEX = BATTERY_MIDDLE_INDEX - BATTERY_HWIDTH
    BATTERY_END_INDEX = BATTERY_MIDDLE_INDEX + BATTERY_HWIDTH

    LOW_BATTERY_BLINK_SPEED = 20

    
    FADE_STAY_TIME = 1
    FADE_OUT_TIME = 1

    NEXT_SCENE = "Idle"


    # Constructor
    def __init__(self) -> None:
        super().__init__("UI Notif Battery Low")




    def start(self) -> None:
        self.scene_start_time = time.now()
        sound.play_file(Scene.SOUND_LOW_BATTERY)
        
    def stop(self) -> None:
        return

    def update(self) -> None:
        local_time = time.now() - self.scene_start_time

        brightness = 0
        if local_time < Scene.FADE_STAY_TIME:
            brightness = 1
        if local_time < Scene.FADE_STAY_TIME + Scene.FADE_OUT_TIME:
            brightness = ease.linear(1, 0, (local_time - Scene.FADE_STAY_TIME) / Scene.FADE_OUT_TIME)
        else:
            scene_manager.set_scene(Scene.NEXT_SCENE)
            return





        lightstrip.clear()

        self.draw_battery_caps(brightness)
        self.draw_battery_contents(brightness)
        window.draw_window(brightness)
        
        lightstrip.show()


    # Draw the small caps and the start end end of the battery
    def draw_battery_caps(self, brightness: float) -> None:

        color_battery_cap = lightstrip.multiply_color_by_float(Scene.COLOR_BATTERY_CAP, brightness)
        lightstrip.draw_line(
            Scene.BATTERY_START_INDEX - 1, 
            Scene.BATTERY_START_INDEX - 1 - Scene.BATTERY_CAP_LENGTH, 
            color_battery_cap
        )
        lightstrip.draw_line(
            Scene.BATTERY_END_INDEX + 1, 
            Scene.BATTERY_END_INDEX + 1 + Scene.BATTERY_CAP_LENGTH, 
            color_battery_cap
        )

    # Draw what should be inside the battery (in this case, a flashing red indication that the battery is low)
    def draw_battery_contents(self, brightness: float) -> None:

        sector_top_start, sector_top_end        = self.get_battery_section(0)   # Get the indexes for the top battey line
        sector_middle_start, sector_middle_end  = self.get_battery_section(1)   # Get the indexes for the middle battery line
        sector_bottom_start, sector_bottom_end  = self.get_battery_section(2)   # Get the indexes for the bottom battery line

        blink_brightness = math.square_wave_abs(time.now() * Scene.LOW_BATTERY_BLINK_SPEED)     # Use a square wave to toggle the brightness on and off
        color_battery_empty = lightstrip.multiply_color_by_float(Scene.COLOR_BATTERY_EMPTY, brightness * blink_brightness)  # Apply the brightness to our bat color
        color_battery_background = lightstrip.multiply_color_by_float(Scene.COLOR_BATTERY_BACKGROUND, brightness)          # Create a simple background color
        
        lightstrip.draw_line(sector_bottom_start, sector_bottom_end, color_battery_empty)       # Draw the blinking battery light
        lightstrip.draw_line(sector_middle_start, sector_middle_end, color_battery_background)  # Draw the blinking battery light
        lightstrip.draw_line(sector_top_start, sector_top_end, color_battery_background)        # Draw the blinking battery light




    # Return the start and end sections for this part of the battery
    def get_battery_section(self, index: int) -> tuple:
        section_start   = math.lerp(Scene.BATTERY_START_INDEX, Scene.BATTERY_END_INDEX, (index) * (1 / 3))          # Get the start position for this index
        section_end     = math.lerp(Scene.BATTERY_START_INDEX, Scene.BATTERY_END_INDEX, (index + 1) * (1 / 3))      # Get the end position for this index
        return (section_start + Scene.BATTERY_SECTION_OFFSET, section_end - Scene.BATTERY_SECTION_OFFSET)