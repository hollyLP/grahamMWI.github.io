from lightpong import *
import system_window_util as window

class Scene(scene_base):

    #
    #   OPTIONS
    #

    COLOR_WIFI_NORMAL = lightstrip.get_color(0, 10, 255)
    WIFI_BAND_SPEED_CONNECTED = 0.75
    WIFI_BAND_SPEED_DISCONNECTED = 0.5

    FADE_IN_TIME = 0.3
    FADE_STAY_TIME = 3
    FADE_OUT_TIME = 0.5

    NEXT_SCENE = "Idle"



    # Constructor
    def __init__(self) -> None:
        super().__init__("UI Notif Comms Enabled")




    def start(self) -> None:
        self.scene_start_time = time.now()
        
    def stop(self) -> None:
        return

    def update(self) -> None:
        local_time = time.now() - self.scene_start_time

        brightness = 0
        if local_time < Scene.FADE_IN_TIME:
            brightness = ease.linear(0, 1, local_time / Scene.FADE_IN_TIME)
        elif local_time < Scene.FADE_IN_TIME + Scene.FADE_STAY_TIME:
            brightness = 1
        elif local_time < Scene.FADE_IN_TIME + Scene.FADE_STAY_TIME + Scene.FADE_OUT_TIME:
            brightness = ease.linear(1, 0, (local_time - Scene.FADE_IN_TIME - Scene.FADE_STAY_TIME) / Scene.FADE_OUT_TIME)
        else:
            scene_manager.set_scene(Scene.NEXT_SCENE)
            return


        lightstrip.clear()

        offsets = [0.0, 0.25, 0.5, 0.75]
        middle = lightstrip.length() / 2

        base_wifi_color = Scene.COLOR_WIFI_NORMAL
        for offset in offsets:
            lerp_time = math.clamp(0, 99999999999, (local_time * Scene.WIFI_BAND_SPEED_DISCONNECTED + offset) - 1) % 1 
            index_lerp = ease.linear(0, lightstrip.length() / 2.5, lerp_time)
            width = ease.linear(0, 6, lerp_time)
            index_L = middle - index_lerp
            index_R = middle + index_lerp

            waver_amount = ease.linear(1, 0.5, math.sine_wave_abs((local_time + offset) * 20))
            wifi_color = lightstrip.multiply_color_by_float(base_wifi_color, ease.linear(1, 0, lerp_time) * brightness * waver_amount)
            lightstrip.draw_line_centered(index_L, width, wifi_color)
            lightstrip.draw_line_centered(index_R, width, wifi_color)

        middle_waver_amount = ease.linear(1, 0.5, math.sine_wave_abs(local_time * 10))
        lightstrip.draw_line_centered(middle, 1, lightstrip.multiply_color_by_float(base_wifi_color, brightness * middle_waver_amount))

        window.draw_window(brightness)

        lightstrip.show()