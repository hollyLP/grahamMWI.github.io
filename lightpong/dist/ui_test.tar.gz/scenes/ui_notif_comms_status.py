from lightpong import *
import system_window_util as window

class Scene(scene_base):

    #
    #   OPTIONS
    #

    COLOR_WIFI_DISABLED = lightstrip.get_color(200, 0, 0)
    COLOR_WIFI_DISABLED_BACKGROUND = lightstrip.get_color(20, 0, 0)

    COLOR_WIFI_CONNECTED = lightstrip.get_color(0, 255, 10)
    COLOR_WIFI_DISCONNECTED = lightstrip.get_color(0, 10, 255)
    WIFI_BAND_SPEED_CONNECTED = 0.75
    WIFI_BAND_SPEED_DISCONNECTED = 0.5

    FADE_IN_TIME = 0.3
    FADE_STAY_TIME = 3
    FADE_OUT_TIME = 0.5

    SOUND_LOOP_TIME = 1.845
    SOUND_COMMS_ENABLED_CONNECTED = 'sounds/comms_enabled_connected.wav'
    SOUND_COMMS_ENABLED_DISCONNECTED = 'sounds/comms_enabled_disconnected.wav'
    SOUND_COMMS_DISABLED = 'sounds/comms_disabled_notif.wav'

    NEXT_SCENE = "Idle"

    # A global flag that toggles this scene between displaying the enabled status or disable status
    VAR_DISPLAY_ENABLED = 0



    # Constructor
    def __init__(self) -> None:
        super().__init__("UI Notif Comms Status")




    def start(self) -> None:
        self.scene_start_time = time.now()
        self.next_play_time = time.now()

        Scene.VAR_DISPLAY_ENABLED = (Scene.VAR_DISPLAY_ENABLED + 1) % 3
        
    def stop(self) -> None:
        return

    def update(self) -> None:
        local_time = time.now() - self.scene_start_time

        brightness = 0
        if local_time < Scene.FADE_IN_TIME:
            brightness = ease.linear(0, 1, local_time / Scene.FADE_IN_TIME)
        elif local_time < Scene.FADE_IN_TIME + Scene.FADE_STAY_TIME:
            brightness = 1
        elif local_time < Scene.FADE_IN_TIME + Scene.FADE_STAY_TIME + Scene.FADE_OUT_TIME:
            brightness = ease.linear(1, 0, (local_time - Scene.FADE_IN_TIME - Scene.FADE_STAY_TIME) / Scene.FADE_OUT_TIME)
        else:
            scene_manager.set_scene(Scene.NEXT_SCENE)
            return
        

        if time.now() >= self.next_play_time:
            if Scene.VAR_DISPLAY_ENABLED is not 0:
                self.next_play_time = time.now() + Scene.SOUND_LOOP_TIME
            else:
                self.next_play_time = time.now() + 99999999

            if Scene.VAR_DISPLAY_ENABLED is 0:
                sound.play_file(Scene.SOUND_COMMS_DISABLED)
            elif Scene.VAR_DISPLAY_ENABLED is 1:
                sound.play_file(Scene.SOUND_COMMS_ENABLED_DISCONNECTED)
            elif Scene.VAR_DISPLAY_ENABLED is 2:
                sound.play_file(Scene.SOUND_COMMS_ENABLED_CONNECTED)


        lightstrip.clear()

        if Scene.VAR_DISPLAY_ENABLED is 0:
            self.draw_disabled(local_time, brightness)
        elif Scene.VAR_DISPLAY_ENABLED is 1:
            self.draw_enabled_disconnected(local_time, brightness)
        elif Scene.VAR_DISPLAY_ENABLED is 2:
            self.draw_enabled_connected(local_time, brightness)

        window.draw_window(brightness)


        lightstrip.show()



    def draw_disabled(self, local_time: float, brightness: float) -> None:
        offsets = [0.0, 0.25, 0.5, 0.75]
        middle = lightstrip.length() / 2

        base_wifi_color = Scene.COLOR_WIFI_DISABLED_BACKGROUND
        for offset in offsets:
            lerp_time = math.clamp(0, 99999999999, (offset + 1) - 1) % 1 
            index_lerp = ease.linear(0, lightstrip.length() / 2.5, lerp_time)
            width = ease.linear(0, 6, lerp_time)
            index_L = middle - index_lerp
            index_R = middle + index_lerp

            waver_amount = ease.linear(1, 0.8, math.square_wave(local_time * 10))
            wifi_color = lightstrip.multiply_color_by_float(base_wifi_color, ease.linear(1, 0.5, lerp_time) * brightness * waver_amount)
            lightstrip.draw_line_centered(index_L, width, wifi_color)
            lightstrip.draw_line_centered(index_R, width, wifi_color)

        middle_waver_amount = ease.linear(1, 0.4, math.square_wave(local_time * 10))
        lightstrip.draw_line_centered(middle, 1, lightstrip.multiply_color_by_float(Scene.COLOR_WIFI_DISABLED, brightness * middle_waver_amount))

    def draw_enabled_connected(self, local_time: float, brightness: float) -> None:
        offsets = [0.0, 0.25, 0.5, 0.75]
        middle = lightstrip.length() / 2

        base_wifi_color = Scene.COLOR_WIFI_CONNECTED
        for offset in offsets:
            lerp_time = math.clamp(0, 99999999999, (local_time * Scene.WIFI_BAND_SPEED_CONNECTED + offset) + 1) % 1 
            index_lerp = ease.linear(0, lightstrip.length() / 2.5, lerp_time)
            width = ease.linear(0, 6, lerp_time)
            index_L = middle - index_lerp
            index_R = middle + index_lerp

            waver_amount = ease.linear(1, 0.5, math.sine_wave_abs((local_time + offset) * 20))
            wifi_color = lightstrip.multiply_color_by_float(base_wifi_color, ease.linear(1, 0, lerp_time) * brightness * waver_amount)
            lightstrip.draw_line_centered(index_L, width, wifi_color)
            lightstrip.draw_line_centered(index_R, width, wifi_color)

        middle_waver_amount = ease.linear(1, 0.5, math.sine_wave_abs(local_time * 10))
        lightstrip.draw_line_centered(middle, 1, lightstrip.multiply_color_by_float(base_wifi_color, brightness * middle_waver_amount))

    def draw_enabled_disconnected(self, local_time: float, brightness: float) -> None:
        offsets = [0.0, 0.25, 0.5, 0.75]
        middle = lightstrip.length() / 2

        base_wifi_color = Scene.COLOR_WIFI_DISCONNECTED
        for offset in offsets:
            lerp_time = math.clamp(0, 99999999999, (local_time * Scene.WIFI_BAND_SPEED_DISCONNECTED + offset) + 1) % 1 
            index_lerp = ease.linear(0, lightstrip.length() / 2.5, lerp_time)
            width = ease.linear(0, 6, lerp_time)
            index_L = middle - index_lerp
            index_R = middle + index_lerp

            waver_amount = ease.linear(1, 0.5, math.sine_wave_abs((local_time + offset) * 20))
            wifi_color = lightstrip.multiply_color_by_float(base_wifi_color, ease.linear(1, 0, lerp_time) * brightness * waver_amount)
            lightstrip.draw_line_centered(index_L, width, wifi_color)
            lightstrip.draw_line_centered(index_R, width, wifi_color)

        middle_waver_amount = ease.linear(1, 0.5, math.sine_wave_abs(local_time * 10))
        lightstrip.draw_line_centered(middle, 1, lightstrip.multiply_color_by_float(base_wifi_color, brightness * middle_waver_amount))