from lightpong import *
import random
import system_window_util as window

class Scene(scene_base):

    class State():
        FADE_IN     = 0x00
        SHRINK      = 0x01
        SNORE       = 0x02
        FADE_OUT    = 0x03

    class Particle():

        def __init__(self, position: int) -> None:
            self.lifetime = random.uniform(0.1, 0.5)
            self.start_time = time.now()
            self.position = position
            self.color = lightstrip.get_color(255, 255, 255)

        # Return true or false depending on if this particle is alive
        def is_alive(self) -> bool:
            return (time.now() - self.start_time) < self.lifetime

        def draw(self, brightness: float) -> None:
            time_since_started = time.now() - self.start_time
            color_mult = ease.cubic_out(1, 0, time_since_started / self.lifetime)

            color = lightstrip.multiply_color_by_float(self.color, color_mult * brightness)
            lightstrip.draw_pixel(self.position, color)

    class ParticleSystem():

        def __init__(self, spawn_rate: float) -> None:
            self.particles = []
            self.last_spawn_time = 0
            self.is_enabled = True
            self.brightness = 1

            self.spawn_rate = spawn_rate

        def set_enabled(self, is_enabled: bool) -> None:
            self.is_enabled = is_enabled

        def get_enabled(self) -> bool:
            return self.is_enabled

        def clear(self) -> None:
            self.particles.clear()

        def set_brightness(self, brightness: float) -> None:
            self.brightness = brightness

        def update(self) -> None:
            time_since_spawn = time.now() - self.last_spawn_time

            # If enough time has passed and we should spawn a new particle...
            if time_since_spawn > self.spawn_rate and self.is_enabled:
                time_since_spawn = time.now()

                position = random.randrange(0, lightstrip.length())
                self.particles.append(Scene.Particle(position))


            # Loop through each particle and look for dead ones
            to_remove = []
            for particle in self.particles:
                if not particle.is_alive():
                    to_remove.append(particle)

            # Remove any particles that are dead
            for dead_particle in to_remove:
                self.particles.remove(dead_particle)

        def draw(self) -> None:
            for particle in self.particles:
                particle.draw(self.brightness)

            


    #
    #   OPTIONS
    #

    FILL_COLOR = lightstrip.get_color(200, 20, 200)

    FADE_IN_TIME = 0.3
    SHRINK_TIME = 0.5
    SNORE_TIME = 1
    FADE_OUT_TIME = 3

    SNORE_HWIDTH = 5
    SNORE_EXPAND_AMOUNT = 7
    SNORE_SPEED = 2.5

    NEXT_SCENE = "Idle"


    PARTICLE_SYSTEM = ParticleSystem(0.3)

    # Constructor
    def __init__(self) -> None:
        super().__init__("UI Sleep")




    def start(self) -> None:
        self.state_start_time = time.now()
        Scene.PARTICLE_SYSTEM.clear()
        Scene.PARTICLE_SYSTEM.set_brightness(0)
        Scene.PARTICLE_SYSTEM.set_enabled(False)

        self.set_state(Scene.State.FADE_IN)
        
    def stop(self) -> None:
        return

    def update(self) -> None:
        lightstrip.clear()
        self.run_state_machine()
        Scene.PARTICLE_SYSTEM.update()
        Scene.PARTICLE_SYSTEM.draw()
        lightstrip.show()






    def set_state(self, new_state: State) -> None:
        self.state = new_state
        self.state_start_time = time.now()

        if new_state is Scene.State.FADE_IN:
            Scene.PARTICLE_SYSTEM.set_enabled(True)
        elif new_state is Scene.State.SHRINK:
            Scene.PARTICLE_SYSTEM.set_enabled(False)
        elif new_state is Scene.State.SNORE:
            self.snore_start_time = time.now()

    def run_state_machine(self) -> None:

        if self.state is Scene.State.FADE_IN:
            self.update_fade_in()
        elif self.state is Scene.State.SHRINK:
            self.update_shrink()
        elif self.state is Scene.State.SNORE:
            self.update_snore()
        elif self.state is Scene.State.FADE_OUT:
            self.update_fade_out()

    def update_fade_in(self) -> None:
        local_time = time.now() - self.state_start_time

        fade_lerp = local_time / Scene.FADE_IN_TIME
        fill_color = lightstrip.multiply_color_by_float(Scene.FILL_COLOR, ease.linear(0, 1, fade_lerp))

        Scene.PARTICLE_SYSTEM.set_brightness(fade_lerp)
        lightstrip.draw_fill(fill_color)

        if fade_lerp > 1:
            self.set_state(Scene.State.SHRINK)

    def update_shrink(self) -> None:
        local_time = time.now() - self.state_start_time

        shrink_lerp = local_time / Scene.SHRINK_TIME
        width = ease.cubic_in(lightstrip.length() / 2, Scene.SNORE_HWIDTH, shrink_lerp)

        lightstrip.draw_line_centered(lightstrip.length() / 2, width, Scene.FILL_COLOR)

        if shrink_lerp > 1:
            self.set_state(Scene.State.SNORE)

    def update_snore(self) -> None:
        local_time = time.now() - self.state_start_time
        snore_time = time.now() - self.snore_start_time

        # Create a snore animation
        snore_lerp = snore_time * Scene.SNORE_SPEED
        snore_lerp = math.sine_wave_abs(snore_lerp)
        self.snore_width = ease.linear(Scene.SNORE_HWIDTH, Scene.SNORE_HWIDTH + Scene.SNORE_EXPAND_AMOUNT, snore_lerp)

        lightstrip.draw_line_centered(lightstrip.length() / 2, self.snore_width, Scene.FILL_COLOR)


        if local_time > Scene.SNORE_TIME:
            self.set_state(Scene.State.FADE_OUT)

    def update_fade_out(self) -> None:
        local_time = time.now() - self.state_start_time
        snore_time = time.now() - self.snore_start_time

        # Modify the fill color so it fades out
        color_amount = ease.quad_out(1, 0, local_time / Scene.FADE_OUT_TIME)
        fill_color = lightstrip.multiply_color_by_float(Scene.FILL_COLOR, color_amount)

        # Contiune the snore animation
        snore_lerp = snore_time * Scene.SNORE_SPEED
        snore_lerp = math.sine_wave_abs(snore_lerp)
        self.snore_width = ease.linear(Scene.SNORE_HWIDTH, Scene.SNORE_HWIDTH + Scene.SNORE_EXPAND_AMOUNT, snore_lerp)

        lightstrip.draw_line_centered(lightstrip.length() / 2, self.snore_width, fill_color)

        if local_time > Scene.FADE_OUT_TIME:
            scene_manager.set_scene(Scene.NEXT_SCENE)


        
